#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Targeted native-Qwen-MTP breakthrough matrix for vLLM Metal.

This benchmark starts from the best complete hosted profile discovered by the
broad search (4096 scheduled tokens, block size 16, lazy GDN kernels, decode
pipeline enabled) and isolates code-level changes instead of sweeping the same
scheduler knobs again.

The measured arms are:

* matched non-MTP controls at the beginning and end of each shard;
* the current native-MTP implementation, including the upstream copyless
  confirmed-to-speculative state path;
* compact deferred GDN state;
* deferred state plus shared verification-window mode; and
* a matched in-process vLLM control/deferred pair.

The copyless path is now part of the shared base, so this matrix measures the
remaining deferred-state intervention without applying a stale source patch.
Every result records deterministic output hashes,
TTFT, after-first-token decode rate, end-to-end throughput, MTP acceptance,
runner drift, and process-group RSS.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import shutil
import signal
import statistics
import subprocess
import time
import urllib.error
import urllib.request
from collections import defaultdict
from collections.abc import Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import aiohttp
from transformers import AutoTokenizer
from vllm.benchmarks.lib.endpoint_request_func import (
    RequestFuncInput,
    RequestFuncOutput,
    async_request_openai_completions,
)
from vllm.benchmarks.serve import fetch_spec_decode_metrics


@dataclass(frozen=True)
class Arm:
    name: str
    mode: str
    deferred: bool = False
    verify_window: bool = False
    decode_pipeline: bool = True
    inprocess: bool = False

    @property
    def baseline_family(self) -> str:
        return "inprocess" if self.inprocess else "default"


@dataclass(frozen=True)
class Workload:
    name: str
    prompt_tokens: int
    output_tokens: int
    concurrency: int
    requests: int


ARMS: tuple[Arm, ...] = (
    Arm("baseline_start", "baseline"),
    Arm("mtp_current", "mtp"),
    Arm("mtp_deferred", "mtp", deferred=True),
    Arm("mtp_deferred_verify", "mtp", deferred=True, verify_window=True),
    Arm("baseline_inproc_start", "baseline", inprocess=True),
    Arm("mtp_deferred_inproc", "mtp", deferred=True, inprocess=True),
    Arm("baseline_inproc_end", "baseline", inprocess=True),
    Arm("baseline_end", "baseline"),
)

WORKLOADS: tuple[Workload, ...] = (
    Workload("interactive_c1", 1152, 128, 1, 4),
    Workload("serving_c4", 1152, 128, 4, 8),
    Workload("serving_c8", 1152, 128, 8, 16),
    Workload("serving_c16", 1152, 64, 16, 32),
    Workload("long_prefix_c1", 8192, 64, 1, 2),
    Workload("long_prefix_c4", 8192, 64, 4, 4),
)

SPEC_CONFIG = '{"method":"mtp","num_speculative_tokens":1}'
DEFAULT_ARMS = ",".join(arm.name for arm in ARMS)
DEFAULT_WORKLOADS = ",".join(item.name for item in WORKLOADS)


def parse_csv(value: str) -> tuple[str, ...]:
    items = tuple(item.strip() for item in value.split(",") if item.strip())
    if not items:
        raise argparse.ArgumentTypeError("expected a non-empty comma-separated list")
    return items


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--mode", choices=("serving", "pressure"), default="serving")
    parser.add_argument("--arms", type=parse_csv, default=parse_csv(DEFAULT_ARMS))
    parser.add_argument(
        "--workloads", type=parse_csv, default=parse_csv(DEFAULT_WORKLOADS)
    )
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--pressure-retained-prefixes", type=int, default=0)
    parser.add_argument("--pressure-probes", type=int, default=5)
    parser.add_argument("--pressure-prompt-tokens", type=int, default=1152)
    parser.add_argument("--pressure-output-tokens", type=int, default=64)
    parser.add_argument("--port", type=int, default=8700)
    parser.add_argument("--max-model-len", type=int, default=8448)
    parser.add_argument("--max-num-seqs", type=int, default=16)
    parser.add_argument("--max-num-batched-tokens", type=int, default=4096)
    parser.add_argument("--block-size", type=int, default=16)
    parser.add_argument("--request-timeout-s", type=float, default=360.0)
    parser.add_argument("--server-ready-timeout-s", type=float, default=900.0)
    args = parser.parse_args()

    if args.repeats < 1 or args.pressure_probes < 1:
        parser.error("repeats and pressure probes must be positive")
    if args.pressure_retained_prefixes < 0:
        parser.error("pressure retained-prefix count cannot be negative")
    if args.max_num_seqs < 1 or args.max_num_batched_tokens < 1:
        parser.error("scheduler limits must be positive")
    known_arms = {arm.name for arm in ARMS}
    unknown_arms = sorted(set(args.arms) - known_arms)
    if unknown_arms:
        parser.error(f"unknown arms: {', '.join(unknown_arms)}")
    known_workloads = {item.name for item in WORKLOADS}
    unknown_workloads = sorted(set(args.workloads) - known_workloads)
    if unknown_workloads:
        parser.error(f"unknown workloads: {', '.join(unknown_workloads)}")
    return args


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def tail(path: Path, lines: int = 300) -> str:
    if not path.exists():
        return "<log file was not created>"
    return "\n".join(path.read_text(errors="replace").splitlines()[-lines:])


def sha256_texts(values: Sequence[str]) -> tuple[str, list[str]]:
    per_item = [hashlib.sha256(value.encode("utf-8")).hexdigest() for value in values]
    payload = json.dumps(values, ensure_ascii=False, separators=(",", ":")).encode(
        "utf-8"
    )
    return hashlib.sha256(payload).hexdigest(), per_item


def selected_by_name(values: Sequence[Any], names: Sequence[str]) -> tuple[Any, ...]:
    wanted = set(names)
    return tuple(value for value in values if value.name in wanted)


def process_group_rss_mb(pgid: int | None) -> float | None:
    if pgid is None:
        return None
    try:
        output = subprocess.check_output(
            ["ps", "-axo", "pgid=,rss="], text=True, stderr=subprocess.DEVNULL
        )
    except Exception:
        return None
    total_kib = 0
    for raw in output.splitlines():
        fields = raw.split()
        if len(fields) != 2:
            continue
        try:
            row_pgid, rss_kib = map(int, fields)
        except ValueError:
            continue
        if row_pgid == pgid:
            total_kib += rss_kib
    return total_kib / 1024 if total_kib else None


class Server:
    def __init__(
        self,
        *,
        arm: Arm,
        model_dir: Path,
        port: int,
        log_path: Path,
        ready_timeout_s: float,
        max_model_len: int,
        max_num_seqs: int,
        max_num_batched_tokens: int,
        block_size: int,
    ) -> None:
        self.arm = arm
        self.model_dir = model_dir
        self.port = port
        self.log_path = log_path
        self.ready_timeout_s = ready_timeout_s
        self.max_model_len = max_model_len
        self.max_num_seqs = max_num_seqs
        self.max_num_batched_tokens = max_num_batched_tokens
        self.block_size = block_size
        self.process: subprocess.Popen[str] | None = None
        self._log_handle: Any = None

    @property
    def pgid(self) -> int | None:
        return self.process.pid if self.process is not None else None

    def rss_mb(self) -> float | None:
        return process_group_rss_mb(self.pgid)

    def start(self) -> None:
        executable = shutil.which("vllm")
        if executable is None:
            raise RuntimeError("vllm executable was not found on PATH")
        command = [
            executable,
            "serve",
            str(self.model_dir),
            "--served-model-name",
            "qwen35-mtp-breakthrough",
            "--enable-prefix-caching",
            "--no-async-scheduling",
            "--max-model-len",
            str(self.max_model_len),
            "--max-num-seqs",
            str(self.max_num_seqs),
            "--max-num-batched-tokens",
            str(self.max_num_batched_tokens),
            "--block-size",
            str(self.block_size),
            "--stream-interval",
            "1",
            "--port",
            str(self.port),
        ]
        if self.arm.mode == "mtp":
            command.extend(["--speculative-config", SPEC_CONFIG])

        env = os.environ.copy()
        env.update(
            {
                "VLLM_METAL_USE_PAGED_ATTENTION": "1",
                "VLLM_METAL_MEMORY_FRACTION": "auto",
                "VLLM_METAL_GDN_LAZY_KERNELS": "1",
                "VLLM_METAL_GDN_DEFER_DECODE_STATE": str(int(self.arm.deferred)),
                "VLLM_METAL_GDN_PREALLOCATE_CHECKPOINTS": "0",
                "VLLM_METAL_SPEC_VERIFY_WINDOW": str(int(self.arm.verify_window)),
                "VLLM_METAL_DECODE_PIPELINE": str(int(self.arm.decode_pipeline)),
                "VLLM_ENABLE_V1_MULTIPROCESSING": str(int(not self.arm.inprocess)),
                "GLOO_SOCKET_IFNAME": "lo0",
            }
        )
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._log_handle = self.log_path.open("w")
        print(
            "SERVER_START="
            + json.dumps(
                {
                    "arm": asdict(self.arm),
                    "command": command,
                    "port": self.port,
                    "env": {
                        key: env[key]
                        for key in (
                            "VLLM_METAL_GDN_DEFER_DECODE_STATE",
                            "VLLM_METAL_SPEC_VERIFY_WINDOW",
                            "VLLM_METAL_DECODE_PIPELINE",
                            "VLLM_ENABLE_V1_MULTIPROCESSING",
                        )
                    },
                },
                sort_keys=True,
            ),
            flush=True,
        )
        self.process = subprocess.Popen(
            command,
            stdout=self._log_handle,
            stderr=subprocess.STDOUT,
            text=True,
            env=env,
            start_new_session=True,
        )
        self._wait_ready()

    def _wait_ready(self) -> None:
        assert self.process is not None
        deadline = time.monotonic() + self.ready_timeout_s
        started = time.monotonic()
        url = f"http://127.0.0.1:{self.port}/v1/models"
        last_error = ""
        while time.monotonic() < deadline:
            return_code = self.process.poll()
            if return_code is not None:
                raise RuntimeError(
                    f"server {self.arm.name} exited with code {return_code}\n"
                    + tail(self.log_path)
                )
            try:
                with urllib.request.urlopen(url, timeout=1.5) as response:
                    if response.status == 200:
                        print(
                            f"Server {self.arm.name} ready in "
                            f"{time.monotonic() - started:.1f}s",
                            flush=True,
                        )
                        return
            except (OSError, urllib.error.URLError) as exc:
                last_error = str(exc)
            time.sleep(2)
        raise RuntimeError(
            f"server {self.arm.name} readiness timed out: {last_error}\n"
            + tail(self.log_path)
        )

    def stop(self) -> None:
        process = self.process
        self.process = None
        if process is None:
            return
        if process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=15)
        if self._log_handle is not None:
            self._log_handle.close()
            self._log_handle = None


class PromptFactory:
    def __init__(self, tokenizer: Any) -> None:
        self.tokenizer = tokenizer
        self._body = (
            "Apple Silicon speculative decoding must preserve exact target-model "
            "semantics while amortizing Qwen GatedDeltaNet and attention state. "
        )
        self._body_ids = self.tokenizer.encode(self._body, add_special_tokens=False)
        if not self._body_ids:
            raise RuntimeError("benchmark body tokenized to an empty sequence")

    def token_ids(self, target: int, *, seed: int) -> list[int]:
        marker = self.tokenizer.encode(
            f"Breakthrough probe {seed:012d}: ", add_special_tokens=False
        )
        ids = list(marker)
        while len(ids) < target:
            needed = target - len(ids)
            ids.extend(self._body_ids[:needed])
        return ids[:target]

    def text(self, target: int, *, seed: int) -> tuple[str, int]:
        ids = self.token_ids(target, seed=seed)
        prompt = self.tokenizer.decode(ids, skip_special_tokens=False)
        actual = len(self.tokenizer.encode(prompt, add_special_tokens=False))
        return prompt, actual


async def fetch_raw_metrics(base_url: str, session: aiohttp.ClientSession) -> str:
    try:
        async with session.get(base_url.rstrip("/") + "/metrics") as response:
            if response.status != 200:
                return f"# HTTP {response.status}\n"
            text = await response.text()
    except Exception as exc:
        return f"# metrics fetch failed: {exc!r}\n"
    prefixes = (
        "vllm:spec_decode",
        "vllm:prefix_cache",
        "vllm:kv_cache",
        "vllm:num_requests",
        "# HELP vllm:spec_decode",
        "# TYPE vllm:spec_decode",
    )
    selected = [line for line in text.splitlines() if line.startswith(prefixes)]
    return "\n".join(selected) + ("\n" if selected else "")


class RequestRunner:
    def __init__(
        self,
        *,
        tokenizer: Any,
        base_url: str,
        request_timeout_s: float,
    ) -> None:
        self.tokenizer = tokenizer
        self.base_url = base_url.rstrip("/")
        self.request_timeout_s = request_timeout_s

    async def served_model(self, session: aiohttp.ClientSession) -> str:
        async with session.get(self.base_url + "/v1/models") as response:
            response.raise_for_status()
            return str((await response.json())["data"][0]["id"])

    async def one(
        self,
        *,
        session: aiohttp.ClientSession,
        served_model: str,
        prompt: str,
        prompt_len: int,
        output_len: int,
        tag: str,
    ) -> RequestFuncOutput:
        request = RequestFuncInput(
            prompt=prompt,
            api_url=self.base_url + "/v1/completions",
            prompt_len=prompt_len,
            output_len=output_len,
            model=served_model,
            ignore_eos=True,
            extra_body={"temperature": 0},
        )
        last_error = ""
        for attempt in range(2):
            started = time.perf_counter()
            try:
                output = await asyncio.wait_for(
                    async_request_openai_completions(request, session),
                    timeout=self.request_timeout_s,
                )
            except TimeoutError as exc:
                last_error = f"timed out: {exc}"
            else:
                if output.success:
                    print(
                        f"{tag}: out={output.output_tokens} "
                        f"ttft_ms={output.ttft * 1000:.1f} "
                        f"e2e_s={time.perf_counter() - started:.2f}",
                        flush=True,
                    )
                    return output
                last_error = str(output.error)
            if attempt == 0:
                await asyncio.sleep(2)
        raise RuntimeError(f"{tag} failed: {last_error}")


async def run_serving_workload(
    *,
    arm: Arm,
    workload: Workload,
    tokenizer: Any,
    server: Server,
    repeats: int,
    request_timeout_s: float,
    metrics_path: Path,
) -> dict[str, Any]:
    base_url = f"http://127.0.0.1:{server.port}"
    timeout = aiohttp.ClientTimeout(total=request_timeout_s)
    factory = PromptFactory(tokenizer)
    prompt, prompt_len = factory.text(workload.prompt_tokens, seed=42)
    runner = RequestRunner(
        tokenizer=tokenizer,
        base_url=base_url,
        request_timeout_s=request_timeout_s,
    )

    async with aiohttp.ClientSession(timeout=timeout) as session:
        served_model = await runner.served_model(session)
        await runner.one(
            session=session,
            served_model=served_model,
            prompt=prompt,
            prompt_len=prompt_len,
            output_len=workload.output_tokens,
            tag=f"{arm.name}/{workload.name}/warmup",
        )
        metrics_before = await fetch_spec_decode_metrics(base_url, session)
        raw_before = await fetch_raw_metrics(base_url, session)
        rss_before = server.rss_mb()

        repeat_rows: list[dict[str, Any]] = []
        all_outputs: list[RequestFuncOutput] = []
        for repeat in range(repeats):
            outputs: list[RequestFuncOutput] = []
            started = time.perf_counter()
            for offset in range(0, workload.requests, workload.concurrency):
                wave_size = min(workload.concurrency, workload.requests - offset)
                wave = await asyncio.gather(
                    *(
                        runner.one(
                            session=session,
                            served_model=served_model,
                            prompt=prompt,
                            prompt_len=prompt_len,
                            output_len=workload.output_tokens,
                            tag=(
                                f"{arm.name}/{workload.name}/r{repeat + 1}:"
                                f"{offset + lane + 1}/{workload.requests}"
                            ),
                        )
                        for lane in range(wave_size)
                    )
                )
                outputs.extend(wave)
            elapsed = time.perf_counter() - started
            all_outputs.extend(outputs)
            total_input = sum(item.prompt_len for item in outputs)
            total_output = sum(item.output_tokens for item in outputs)
            after_first_rates = [
                (item.output_tokens - 1) / (item.latency - item.ttft)
                for item in outputs
                if item.output_tokens > 1 and item.latency > item.ttft
            ]
            repeat_rows.append(
                {
                    "repeat": repeat + 1,
                    "elapsed_s": elapsed,
                    "output_throughput_tok_s": total_output / elapsed,
                    "logical_total_token_throughput_tok_s": (total_input + total_output)
                    / elapsed,
                    "mean_ttft_ms": statistics.mean(
                        item.ttft * 1000 for item in outputs
                    ),
                    "median_ttft_ms": statistics.median(
                        item.ttft * 1000 for item in outputs
                    ),
                    "mean_e2e_ms": statistics.mean(
                        item.latency * 1000 for item in outputs
                    ),
                    "median_decode_tok_s_after_first": (
                        statistics.median(after_first_rates)
                        if after_first_rates
                        else None
                    ),
                }
            )

        metrics_after = await fetch_spec_decode_metrics(base_url, session)
        raw_after = await fetch_raw_metrics(base_url, session)
        rss_after = server.rss_mb()

    metrics_path.write_text("# BEFORE\n" + raw_before + "# AFTER\n" + raw_after)
    draft_tokens = accepted_tokens = 0
    if metrics_before is not None and metrics_after is not None:
        draft_tokens = metrics_after.num_draft_tokens - metrics_before.num_draft_tokens
        accepted_tokens = (
            metrics_after.num_accepted_tokens - metrics_before.num_accepted_tokens
        )

    generated = [str(item.generated_text) for item in all_outputs]
    output_hash, per_request_hashes = sha256_texts(generated)
    output_rates = [row["output_throughput_tok_s"] for row in repeat_rows]
    total_rates = [row["logical_total_token_throughput_tok_s"] for row in repeat_rows]
    decode_rates = [
        row["median_decode_tok_s_after_first"]
        for row in repeat_rows
        if row["median_decode_tok_s_after_first"] is not None
    ]
    result = {
        "kind": "serving",
        "arm": arm.name,
        "arm_config": asdict(arm),
        "workload": workload.name,
        "workload_config": asdict(workload),
        "repeats": repeats,
        "output_throughput_tok_s": statistics.median(output_rates),
        "output_throughput_min_tok_s": min(output_rates),
        "output_throughput_max_tok_s": max(output_rates),
        "output_throughput_cv": (
            statistics.pstdev(output_rates) / statistics.mean(output_rates)
            if len(output_rates) > 1
            else 0.0
        ),
        "logical_total_token_throughput_tok_s": statistics.median(total_rates),
        "mean_ttft_ms": statistics.median(row["mean_ttft_ms"] for row in repeat_rows),
        "median_ttft_ms": statistics.median(item.ttft * 1000 for item in all_outputs),
        "mean_e2e_ms": statistics.median(row["mean_e2e_ms"] for row in repeat_rows),
        "median_decode_tok_s_after_first": (
            statistics.median(decode_rates) if decode_rates else None
        ),
        "mtp_draft_tokens": draft_tokens,
        "mtp_accepted_tokens": accepted_tokens,
        "mtp_acceptance_rate": (
            accepted_tokens / draft_tokens if draft_tokens else None
        ),
        "output_sha256": output_hash,
        "per_request_output_sha256": per_request_hashes,
        "unique_output_hashes": sorted(set(per_request_hashes)),
        "process_group_rss_mb_before": rss_before,
        "process_group_rss_mb_after": rss_after,
        "repeat_metrics": repeat_rows,
    }
    print("BREAKTHROUGH_RESULT=" + json.dumps(result, sort_keys=True), flush=True)
    return result


async def run_pressure_workload(
    *,
    arm: Arm,
    tokenizer: Any,
    server: Server,
    retained_prefixes: int,
    probes: int,
    prompt_tokens: int,
    output_tokens: int,
    request_timeout_s: float,
    metrics_path: Path,
) -> dict[str, Any]:
    base_url = f"http://127.0.0.1:{server.port}"
    timeout = aiohttp.ClientTimeout(total=request_timeout_s)
    factory = PromptFactory(tokenizer)
    runner = RequestRunner(
        tokenizer=tokenizer,
        base_url=base_url,
        request_timeout_s=request_timeout_s,
    )

    async with aiohttp.ClientSession(timeout=timeout) as session:
        served_model = await runner.served_model(session)
        for offset in range(0, retained_prefixes, 4):
            batch_size = min(4, retained_prefixes - offset)
            await asyncio.gather(
                *(
                    runner.one(
                        session=session,
                        served_model=served_model,
                        prompt=factory.text(prompt_tokens, seed=10_000 + offset + lane)[
                            0
                        ],
                        prompt_len=factory.text(
                            prompt_tokens, seed=10_000 + offset + lane
                        )[1],
                        output_len=1,
                        tag=(
                            f"{arm.name}/pressure{retained_prefixes}/prime:"
                            f"{offset + lane + 1}/{retained_prefixes}"
                        ),
                    )
                    for lane in range(batch_size)
                )
            )

        # Warm the kernels using a unique non-measured prompt; it cannot produce
        # a hit for any measured probe because its first block is different.
        warm_prompt, warm_len = factory.text(prompt_tokens, seed=800_000)
        await runner.one(
            session=session,
            served_model=served_model,
            prompt=warm_prompt,
            prompt_len=warm_len,
            output_len=output_tokens,
            tag=f"{arm.name}/pressure{retained_prefixes}/warmup",
        )
        metrics_before = await fetch_spec_decode_metrics(base_url, session)
        raw_before = await fetch_raw_metrics(base_url, session)
        rss_before = server.rss_mb()

        outputs: list[RequestFuncOutput] = []
        started = time.perf_counter()
        for probe in range(probes):
            prompt, prompt_len = factory.text(prompt_tokens, seed=1_000_000 + probe)
            outputs.append(
                await runner.one(
                    session=session,
                    served_model=served_model,
                    prompt=prompt,
                    prompt_len=prompt_len,
                    output_len=output_tokens,
                    tag=(
                        f"{arm.name}/pressure{retained_prefixes}/probe:"
                        f"{probe + 1}/{probes}"
                    ),
                )
            )
        elapsed = time.perf_counter() - started
        metrics_after = await fetch_spec_decode_metrics(base_url, session)
        raw_after = await fetch_raw_metrics(base_url, session)
        rss_after = server.rss_mb()

    metrics_path.write_text("# BEFORE\n" + raw_before + "# AFTER\n" + raw_after)
    draft_tokens = accepted_tokens = 0
    if metrics_before is not None and metrics_after is not None:
        draft_tokens = metrics_after.num_draft_tokens - metrics_before.num_draft_tokens
        accepted_tokens = (
            metrics_after.num_accepted_tokens - metrics_before.num_accepted_tokens
        )
    generated = [str(item.generated_text) for item in outputs]
    output_hash, per_request_hashes = sha256_texts(generated)
    total_output = sum(item.output_tokens for item in outputs)
    total_input = sum(item.prompt_len for item in outputs)
    after_first_rates = [
        (item.output_tokens - 1) / (item.latency - item.ttft)
        for item in outputs
        if item.output_tokens > 1 and item.latency > item.ttft
    ]
    result = {
        "kind": "pressure",
        "arm": arm.name,
        "arm_config": asdict(arm),
        "workload": f"retained_prefixes_{retained_prefixes}",
        "retained_prefixes": retained_prefixes,
        "pressure_probes": probes,
        "prompt_tokens_per_probe": total_input / len(outputs),
        "output_tokens_per_probe": output_tokens,
        "elapsed_s": elapsed,
        "output_throughput_tok_s": total_output / elapsed,
        "logical_total_token_throughput_tok_s": (total_input + total_output) / elapsed,
        "mean_ttft_ms": statistics.mean(item.ttft * 1000 for item in outputs),
        "median_ttft_ms": statistics.median(item.ttft * 1000 for item in outputs),
        "mean_e2e_ms": statistics.mean(item.latency * 1000 for item in outputs),
        "median_decode_tok_s_after_first": (
            statistics.median(after_first_rates) if after_first_rates else None
        ),
        "mtp_draft_tokens": draft_tokens,
        "mtp_accepted_tokens": accepted_tokens,
        "mtp_acceptance_rate": (
            accepted_tokens / draft_tokens if draft_tokens else None
        ),
        "output_sha256": output_hash,
        "per_request_output_sha256": per_request_hashes,
        "unique_output_hashes": sorted(set(per_request_hashes)),
        "process_group_rss_mb_before": rss_before,
        "process_group_rss_mb_after": rss_after,
    }
    print("PRESSURE_RESULT=" + json.dumps(result, sort_keys=True), flush=True)
    return result


def baseline_for_row(
    row: dict[str, Any],
    rows_by_workload: dict[str, list[dict[str, Any]]],
) -> float | None:
    family = row["arm_config"].get("inprocess", False)
    controls = (
        {"baseline_inproc_start", "baseline_inproc_end"}
        if family
        else {"baseline_start", "baseline_end"}
    )
    rates = [
        item["output_throughput_tok_s"]
        for item in rows_by_workload[row["workload"]]
        if item["arm"] in controls
    ]
    return statistics.median(rates) if rates else None


def aggregate(
    *,
    output_dir: Path,
    rows: list[dict[str, Any]],
    errors: list[dict[str, Any]],
    args: argparse.Namespace,
) -> tuple[dict[str, Any], str, bool]:
    by_workload: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_workload[row["workload"]].append(row)

    hashes_by_workload: dict[str, str] = {}
    for workload, workload_rows in by_workload.items():
        baseline = next(
            (item for item in workload_rows if item["arm"] == "baseline_start"),
            None,
        )
        if baseline is not None:
            hashes_by_workload[workload] = baseline["output_sha256"]

    mtp_current_rates = {
        workload: next(
            (
                item["output_throughput_tok_s"]
                for item in workload_rows
                if item["arm"] == "mtp_current"
            ),
            None,
        )
        for workload, workload_rows in by_workload.items()
    }
    for row in rows:
        baseline = baseline_for_row(row, by_workload)
        row["speedup_vs_matched_baseline"] = (
            row["output_throughput_tok_s"] / baseline if baseline else None
        )
        current = mtp_current_rates.get(row["workload"])
        row["speedup_vs_mtp_current"] = (
            row["output_throughput_tok_s"] / current
            if current and row["arm_config"]["mode"] == "mtp"
            else None
        )
        expected_hash = hashes_by_workload.get(row["workload"])
        row["output_matches_baseline"] = (
            row["output_sha256"] == expected_hash if expected_hash else None
        )

    expected_workloads = set(by_workload)
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if row["arm_config"]["mode"] == "mtp":
            grouped[row["arm"]].append(row)

    ranking: list[dict[str, Any]] = []
    incomplete: list[dict[str, Any]] = []
    for arm_name, arm_rows in grouped.items():
        completed = {row["workload"] for row in arm_rows}
        speedups = [
            row["speedup_vs_matched_baseline"]
            for row in arm_rows
            if row["speedup_vs_matched_baseline"] is not None
        ]
        current_gains = [
            row["speedup_vs_mtp_current"]
            for row in arm_rows
            if row["speedup_vs_mtp_current"] is not None
        ]
        item = {
            "arm": arm_name,
            "workloads_completed": len(completed),
            "complete": completed == expected_workloads,
            "geomean_speedup_vs_baseline": (
                statistics.geometric_mean(speedups) if speedups else None
            ),
            "minimum_speedup_vs_baseline": min(speedups) if speedups else None,
            "maximum_speedup_vs_baseline": max(speedups) if speedups else None,
            "geomean_gain_vs_mtp_current": (
                statistics.geometric_mean(current_gains) if current_gains else None
            ),
            "all_outputs_match_baseline": all(
                row.get("output_matches_baseline") is True for row in arm_rows
            ),
        }
        (ranking if item["complete"] else incomplete).append(item)

    ranking.sort(
        key=lambda item: item.get("geomean_speedup_vs_baseline") or 0.0,
        reverse=True,
    )
    incomplete.sort(
        key=lambda item: (
            item["workloads_completed"],
            item.get("geomean_speedup_vs_baseline") or 0.0,
        ),
        reverse=True,
    )

    drift: dict[str, float] = {}
    inproc_drift: dict[str, float] = {}
    for workload, workload_rows in by_workload.items():
        mapping = {item["arm"]: item for item in workload_rows}
        if {"baseline_start", "baseline_end"} <= mapping.keys():
            drift[workload] = (
                mapping["baseline_end"]["output_throughput_tok_s"]
                / mapping["baseline_start"]["output_throughput_tok_s"]
                - 1
            )
        if {"baseline_inproc_start", "baseline_inproc_end"} <= mapping.keys():
            inproc_drift[workload] = (
                mapping["baseline_inproc_end"]["output_throughput_tok_s"]
                / mapping["baseline_inproc_start"]["output_throughput_tok_s"]
                - 1
            )

    summary = {
        "git_sha": os.environ.get("GITHUB_SHA"),
        "mode": args.mode,
        "selected_arms": list(args.arms),
        "selected_workloads": list(args.workloads),
        "scheduler": {
            "max_model_len": args.max_model_len,
            "max_num_seqs": args.max_num_seqs,
            "max_num_batched_tokens": args.max_num_batched_tokens,
            "block_size": args.block_size,
        },
        "best_complete_arm": ranking[0] if ranking else None,
        "ranking": ranking,
        "incomplete_arms": incomplete,
        "default_baseline_drift": drift,
        "inprocess_baseline_drift": inproc_drift,
        "errors": errors,
        "rows": rows,
    }
    write_json(output_dir / "breakthrough_summary.json", summary)

    def fmt_ratio(value: float | None) -> str:
        return "n/a" if value is None else f"{value:.3f}x"

    def fmt_pct(value: float | None) -> str:
        return "n/a" if value is None else f"{100 * value:.1f}%"

    lines = [
        "# Qwen native MTP breakthrough matrix",
        "",
        f"- Mode: `{args.mode}`",
        f"- Commit: `{summary['git_sha']}`",
        f"- Scheduler: `{summary['scheduler']}`",
        f"- Errors: **{len(errors)}**",
        "",
        "## Complete MTP arm ranking",
        "",
        "| Rank | Arm | Geomean vs baseline | Worst | Best | vs current MTP | Hash parity |",
        "|---:|---|---:|---:|---:|---:|:---:|",
    ]
    for index, item in enumerate(ranking, 1):
        lines.append(
            f"| {index} | {item['arm']} | "
            f"{fmt_ratio(item['geomean_speedup_vs_baseline'])} | "
            f"{fmt_ratio(item['minimum_speedup_vs_baseline'])} | "
            f"{fmt_ratio(item['maximum_speedup_vs_baseline'])} | "
            f"{fmt_ratio(item['geomean_gain_vs_mtp_current'])} | "
            f"{item['all_outputs_match_baseline']} |"
        )
    if not ranking:
        lines.append("| — | No complete MTP arm | — | — | — | — | — |")

    lines.extend(
        [
            "",
            "## Measurements",
            "",
            "| Workload | Arm | Output tok/s | vs baseline | vs current MTP | TTFT ms | Decode tok/s | E2E ms | Accept | CV | Hash | RSS MB |",
            "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|:---:|---:|",
        ]
    )
    for workload in sorted(by_workload):
        for row in sorted(
            by_workload[workload],
            key=lambda item: item["output_throughput_tok_s"],
            reverse=True,
        ):
            lines.append(
                f"| {workload} | {row['arm']} | "
                f"{row['output_throughput_tok_s']:.2f} | "
                f"{fmt_ratio(row.get('speedup_vs_matched_baseline'))} | "
                f"{fmt_ratio(row.get('speedup_vs_mtp_current'))} | "
                f"{row['mean_ttft_ms']:.1f} | "
                f"{row.get('median_decode_tok_s_after_first') or 0.0:.2f} | "
                f"{row['mean_e2e_ms']:.1f} | "
                f"{fmt_pct(row.get('mtp_acceptance_rate'))} | "
                f"{100 * row.get('output_throughput_cv', 0.0):.1f}% | "
                f"{row.get('output_matches_baseline')} | "
                f"{row.get('process_group_rss_mb_after') or 0.0:.0f} |"
            )

    if drift:
        lines.extend(["", "## Baseline drift", ""])
        for workload, value in sorted(drift.items()):
            lines.append(f"- `{workload}` default-process drift: {value:+.2%}")
        for workload, value in sorted(inproc_drift.items()):
            lines.append(f"- `{workload}` in-process drift: {value:+.2%}")
    if errors:
        lines.extend(["", "## Failed cases", ""])
        lines.extend(
            f"- `{item.get('arm')}/{item.get('workload', 'server')}`: {item['error']}"
            for item in errors
        )

    report = "\n".join(lines) + "\n"
    (output_dir / "breakthrough_summary.md").write_text(report)
    correctness_ok = all(
        row.get("output_matches_baseline") is not False
        for row in rows
        if row["arm_config"]["mode"] == "mtp"
    )
    candidate_complete = any(
        item["arm"] in {"mtp_deferred", "mtp_deferred_inproc"} for item in ranking
    )
    return summary, report, correctness_ok and candidate_complete


async def async_main(args: argparse.Namespace) -> int:
    output_dir: Path = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "logs").mkdir(exist_ok=True)
    (output_dir / "results").mkdir(exist_ok=True)
    (output_dir / "metrics").mkdir(exist_ok=True)

    arms = selected_by_name(ARMS, args.arms)
    workloads = selected_by_name(WORKLOADS, args.workloads)
    write_json(output_dir / "selected_arms.json", [asdict(item) for item in arms])
    write_json(
        output_dir / "selected_workloads.json",
        [asdict(item) for item in workloads],
    )

    tokenizer = AutoTokenizer.from_pretrained(
        str(args.model_dir), trust_remote_code=True
    )
    rows: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    port = args.port

    for arm in arms:
        if args.mode == "serving":
            server = Server(
                arm=arm,
                model_dir=args.model_dir,
                port=port,
                log_path=output_dir / "logs" / f"{arm.name}.log",
                ready_timeout_s=args.server_ready_timeout_s,
                max_model_len=args.max_model_len,
                max_num_seqs=args.max_num_seqs,
                max_num_batched_tokens=args.max_num_batched_tokens,
                block_size=args.block_size,
            )
            port += 1
            try:
                server.start()
                for workload in workloads:
                    try:
                        result = await run_serving_workload(
                            arm=arm,
                            workload=workload,
                            tokenizer=tokenizer,
                            server=server,
                            repeats=args.repeats,
                            request_timeout_s=args.request_timeout_s,
                            metrics_path=(
                                output_dir
                                / "metrics"
                                / f"{arm.name}__{workload.name}.txt"
                            ),
                        )
                    except Exception as exc:
                        errors.append(
                            {
                                "arm": arm.name,
                                "workload": workload.name,
                                "error": str(exc),
                            }
                        )
                        print(
                            f"::warning::{arm.name}/{workload.name} failed: {exc}",
                            flush=True,
                        )
                        continue
                    rows.append(result)
                    write_json(
                        output_dir / "results" / f"{arm.name}__{workload.name}.json",
                        result,
                    )
            except Exception as exc:
                errors.append(
                    {"arm": arm.name, "workload": "server", "error": str(exc)}
                )
                print(f"::warning::{arm.name} server failed: {exc}", flush=True)
            finally:
                server.stop()
                print(f"===== {arm.name} server log tail =====", flush=True)
                print(tail(server.log_path), flush=True)
                await asyncio.sleep(3)
        else:
            # Pressure stages require a fresh server per arm so every arm
            # begins with exactly the requested retained-prefix population.
            server = Server(
                arm=arm,
                model_dir=args.model_dir,
                port=port,
                log_path=(
                    output_dir
                    / "logs"
                    / f"{arm.name}__pressure{args.pressure_retained_prefixes}.log"
                ),
                ready_timeout_s=args.server_ready_timeout_s,
                max_model_len=args.max_model_len,
                max_num_seqs=args.max_num_seqs,
                max_num_batched_tokens=args.max_num_batched_tokens,
                block_size=args.block_size,
            )
            port += 1
            workload_name = f"retained_prefixes_{args.pressure_retained_prefixes}"
            try:
                server.start()
                result = await run_pressure_workload(
                    arm=arm,
                    tokenizer=tokenizer,
                    server=server,
                    retained_prefixes=args.pressure_retained_prefixes,
                    probes=args.pressure_probes,
                    prompt_tokens=args.pressure_prompt_tokens,
                    output_tokens=args.pressure_output_tokens,
                    request_timeout_s=args.request_timeout_s,
                    metrics_path=(
                        output_dir / "metrics" / f"{arm.name}__{workload_name}.txt"
                    ),
                )
                rows.append(result)
                write_json(
                    output_dir / "results" / f"{arm.name}__{workload_name}.json",
                    result,
                )
            except Exception as exc:
                errors.append(
                    {"arm": arm.name, "workload": workload_name, "error": str(exc)}
                )
                print(
                    f"::warning::{arm.name}/{workload_name} failed: {exc}",
                    flush=True,
                )
            finally:
                server.stop()
                print(f"===== {arm.name} pressure server log tail =====", flush=True)
                print(tail(server.log_path), flush=True)
                await asyncio.sleep(3)

    summary, report, passed = aggregate(
        output_dir=output_dir,
        rows=rows,
        errors=errors,
        args=args,
    )
    print(report, flush=True)
    print(
        "BREAKTHROUGH_FINAL="
        + json.dumps(
            {
                "best_complete_arm": summary["best_complete_arm"],
                "errors": len(errors),
                "passed_correctness_gate": passed,
            },
            sort_keys=True,
        ),
        flush=True,
    )
    return 0 if passed else 2


def main() -> int:
    args = parse_args()
    try:
        return asyncio.run(async_main(args))
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
